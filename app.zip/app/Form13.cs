﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace B210109063_SeymenCanAydogan
{
    public partial class Form13 : Form
    {
        public Form13()
        {
            InitializeComponent();
        }
        SqlConnection bag = new SqlConnection("server=HP-LAPTOP\\SQLEXPRESS; Initial Catalog=Hospital_Database; Integrated Security=SSPI");

        private void ClearControls()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            richTextBox1.Text = "";
            richTextBox2.Text = "";
        }
        void dataTablo1()
        {
            string queryx = "SELECT * FROM Examination";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
        }

        void dataTablo2()
        {
            string queryx = "SELECT * FROM Patient";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView2.DataSource = dataTable;
            }
        }

        private void Form13_Load(object sender, EventArgs e)
        {
            dataTablo1();
            dataTablo2();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string patient_Name = textBox3.Text;
            string queryx = $"SELECT * FROM Patient WHERE P_Name='{patient_Name}'";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView2.DataSource = dataTable;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataTablo2();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Examination SET ExaminationDiag=@exdiag,ExaminationRes=@exres WHERE ExaminationID=@exId";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@exdiag", richTextBox1.Text);
                    command.Parameters.AddWithValue("@exres", richTextBox2.Text);
                    command.Parameters.AddWithValue("@exId", int.Parse(textBox1.Text));

                    int rowAffected = command.ExecuteNonQuery();
                    dataTablo1();
                    if (rowAffected > 0)
                    {
                        MessageBox.Show("Muayene Kayıt başarıyla güncellendi");
                        ClearControls();
                    }
                    else { MessageBox.Show("Güncelleme Başarısız. ID Bulunamadı!"); }

                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Examination WHERE PatientID = @patientId";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@patientId", textBox2.Text);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dT = new DataTable();
                    adapter.Fill(dT);
                    dataGridView1.DataSource = dT;

                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            this.Hide();
            form6.Show();
        }
    }
}
