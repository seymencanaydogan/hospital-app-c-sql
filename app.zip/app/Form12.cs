﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace B210109063_SeymenCanAydogan
{
    public partial class Form12 : Form
    {
        public Form12()
        {
            InitializeComponent();
        }
        SqlConnection bag = new SqlConnection("server=HP-LAPTOP\\SQLEXPRESS; Initial Catalog=Hospital_Database; Integrated Security=SSPI");

        void dataTablo1()
        {
            string queryx = "SELECT Staff.StaffID, Staff.S_Name, Staff.S_Surname, Clinic.ClinicName FROM Staff JOIN Clinic ON Staff.ClinicID = Clinic.ClinicID";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView2.DataSource = dataTable;
            }
        }

        void dataTablo2()
        {
            string queryx = "SELECT C.ClinicID, C.ClinicName,C.ClinicFee, C.InternalTel, H.CommercialName FROM Clinic C INNER JOIN Hospital H ON C.HospID=H.HospID";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
        }

        void dataTablo3()
        {
            string queryx = "SELECT R.RoomID, R.RoomNo,S.ServiceTitle, R.RoomEquip, R.RoomCapacity, R.RoomType FROM Rooms R INNER JOIN Service_ S ON R.ServiceID=S.ServiceID";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView4.DataSource = dataTable;
            }
        }
        void dataTablo4()
        {
            string queryx = "SELECT * FROM Service_";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView3.DataSource = dataTable;
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            this.Hide();
            form5.Show();
        }

        private void Form12_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hospital_DatabaseDataSet.Hospital' table. You can move, or remove it, as needed.
            this.hospitalTableAdapter.Fill(this.hospital_DatabaseDataSet.Hospital);
            dataTablo1();
            dataTablo2();
            dataTablo3();
            dataTablo4();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string staff_Name = textBox1.Text;
            string queryx = $"SELECT Staff.StaffID, Staff.S_Name, Staff.S_Surname, Clinic.ClinicName FROM Staff JOIN Clinic ON Staff.ClinicID = Clinic.ClinicID WHERE Staff.S_Name='{staff_Name}'";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView2.DataSource = dataTable;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            dataTablo1();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string clinic_Name = textBox2.Text;
            string queryx = $"SELECT C.ClinicID, C.ClinicName,C.ClinicFee, C.InternalTel, H.CommercialName FROM Clinic C INNER JOIN Hospital H ON C.HospID=H.HospID WHERE C.ClinicName='{clinic_Name}'";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            dataTablo2();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string service_Name = textBox3.Text;
            string queryx = $"SELECT * FROM Service_ WHERE ServiceTitle='{service_Name}'";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView3.DataSource = dataTable;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            dataTablo4();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int odaNo = int.Parse(textBox4.Text);
            string queryx = $"SELECT R.RoomID, R.RoomNo,S.ServiceTitle, R.RoomEquip, R.RoomCapacity, R.RoomType FROM Rooms R INNER JOIN Service_ S ON R.ServiceID=S.ServiceID WHERE R.RoomNo='{odaNo}'";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView4.DataSource = dataTable;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            dataTablo3();
        }
    }
}
