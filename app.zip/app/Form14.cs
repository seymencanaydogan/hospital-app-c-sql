﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace B210109063_SeymenCanAydogan
{
    public partial class Form14 : Form
    {
        public Form14()
        {
            InitializeComponent();
        }
        SqlConnection bag = new SqlConnection("server=HP-LAPTOP\\SQLEXPRESS; Initial Catalog=Hospital_Database; Integrated Security=SSPI");

        private void ClearControls()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
        }

        void dataTablo1()
        {
            string queryx = "SELECT * FROM Prescription";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
        }

        void dataTablo2()
        {
            string queryx = "SELECT * FROM Medicine";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView2.DataSource = dataTable;
            }
        }

        void dataTablo3()
        {
            string queryx = "SELECT * FROM MedicinePres";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView3.DataSource = dataTable;
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Prescription(ExaminationID,PrescriptionDate) VALUES(@exId,@presDate)";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@exId", int.Parse(textBox2.Text));
                    command.Parameters.AddWithValue("@presDate", dateTimePicker1.Value.ToString("yyyy-MM-dd"));
                    command.ExecuteNonQuery();
                    dataTablo1();
                    MessageBox.Show("Reçete başarıyla eklendi");
                    ClearControls();
                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }

            bag.Close();
        }

        private void Form14_Load(object sender, EventArgs e)
        {
            dataTablo1();
            dataTablo2();
            dataTablo3();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM Prescription WHERE PrescriptionID=@presId";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@presId", int.Parse(textBox1.Text));

                    int rowAffected = command.ExecuteNonQuery();
                    dataTablo1();
                    if (rowAffected > 0)
                    {
                        MessageBox.Show("Reçete Kayıt başarıyla silindi");
                        ClearControls();
                    }
                    else { MessageBox.Show("Silme Başarısız. ID Bulunamadı!"); }
                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Prescription WHERE ExaminationID = @exId";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@exId", int.Parse(textBox2.Text));

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dT = new DataTable();
                    adapter.Fill(dT);
                    dataGridView1.DataSource = dT;

                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Medicine WHERE MedicineTitle = @medTit";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@medTit", textBox3.Text);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dT = new DataTable();
                    adapter.Fill(dT);
                    dataGridView2.DataSource = dT;

                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataTablo2();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO MedicinePres(MedicineID,PrescriptionID) VALUES(@medId,@presId)";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@medId", int.Parse(textBox4.Text));
                    command.Parameters.AddWithValue("@presId", int.Parse(textBox5.Text));
                    command.ExecuteNonQuery();
                    dataTablo3();
                    MessageBox.Show("Reçeteye İlaç başarıyla eklendi");
                    ClearControls();
                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();

        }

        private void button7_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM MedicinePres WHERE PrescriptionID=@presId AND MedicineID=@medId";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@presId", int.Parse(textBox5.Text));
                    command.Parameters.AddWithValue("@medId", int.Parse(textBox4.Text));

                    int rowAffected = command.ExecuteNonQuery();
                    dataTablo3();
                    if (rowAffected > 0)
                    {
                        MessageBox.Show("Reçeteden İlaç Kaydı başarıyla silindi");
                        ClearControls();
                    }
                    else { MessageBox.Show("Silme Başarısız. ID Bulunamadı!"); }
                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM MedicinePres WHERE MedicineID = @medicineId";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@medicineId", int.Parse(textBox4.Text));

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dT = new DataTable();
                    adapter.Fill(dT);
                    dataGridView3.DataSource = dT;

                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            this.Hide();
            form6.Show();
        }
    }
}
