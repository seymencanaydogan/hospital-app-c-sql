﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace B210109063_SeymenCanAydogan
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
        }
        SqlConnection bag = new SqlConnection("server=HP-LAPTOP\\SQLEXPRESS; Initial Catalog=Hospital_Database; Integrated Security=SSPI");

        void dataTablo1()
        {
            string queryx = "SELECT * FROM ExaminationAn";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
        }

        void dataTablo2()
        {
            string queryx = "SELECT * FROM Analysis";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView2.DataSource = dataTable;
            }
        }

        void dataTablo3()
        {
            string queryx = "SELECT * FROM Examination ORDER BY ExaminationDate DESC";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView3.DataSource = dataTable;
            }
        }
        private void Form11_Load(object sender, EventArgs e)
        {
            dataTablo1();
            dataTablo2();
            dataTablo3();
        }
        private void ClearControls()
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO ExaminationAn(AnalysisID,ExaminationID) VALUES(@anId,@exId)";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@anId", int.Parse(textBox2.Text));
                    command.Parameters.AddWithValue("@exId", int.Parse(textBox1.Text));
                    command.ExecuteNonQuery();
                    dataTablo1();
                    MessageBox.Show("Muayene Tahlil Kayıt başarıyla eklendi");
                    ClearControls();
                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }

            bag.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "UPDATE ExaminationAn SET AnalysisID=@anId WHERE ExaminationID=@exId";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@anId", int.Parse(textBox2.Text));
                    command.Parameters.AddWithValue("@exId", int.Parse(textBox1.Text));

                    int rowAffected = command.ExecuteNonQuery();
                    dataTablo1();
                    if (rowAffected > 0)
                    {
                        MessageBox.Show("Muayene Tahlil Kayıt başarıyla güncellendi");
                        ClearControls();
                    }
                    else { MessageBox.Show("Güncelleme Başarısız. ID Bulunamadı!"); }

                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM ExaminationAn WHERE ExaminationID=@exId";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@exId", int.Parse(textBox1.Text));

                    int rowAffected = command.ExecuteNonQuery();
                    dataTablo1();
                    if (rowAffected > 0)
                    {
                        MessageBox.Show("Tahlil Kayıt başarıyla silindi");
                        ClearControls();
                    }
                    else { MessageBox.Show("Silme Başarısız. ID Bulunamadı!"); }
                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM ExaminationAn WHERE ExaminationID=@exId";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@exId", int.Parse(textBox1.Text));

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dT = new DataTable();
                    adapter.Fill(dT);
                    dataGridView1.DataSource = dT;

                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            this.Hide();
            form5.Show();
        }
    }
}

