﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace B210109063_SeymenCanAydogan
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }
        SqlConnection bag = new SqlConnection("server=HP-LAPTOP\\SQLEXPRESS; Initial Catalog=Hospital_Database; Integrated Security=SSPI");
        void dataTablo()
        {
            string queryx = "SELECT * FROM Patient";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
        }
        private void Form8_Load(object sender, EventArgs e)
        {
            dataTablo();
        }
        private void ClearControls()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            dateTimePicker1.Checked = false;
            dateTimePicker2.Checked = false;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string Cinsiyet = "NULL";
            string query = "INSERT INTO Patient (TaxNo,TcNo,P_Name,P_Surname,Address_,Birthdate,Sex,MobileNo,Email,RegisterDate) VALUES(@TaxNo,@TcNo,@P_Name,@P_Surname,@Address_,@Birthdate,@Sex,@MobileNo,@Email,@RegisterDate)";
            if (radioButton1.Checked) { Cinsiyet = radioButton1.Text.Substring(0, 1); }
            else if (radioButton2.Checked) { Cinsiyet = radioButton2.Text.Substring(0, 1); }
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@TaxNo", textBox2.Text);
                    command.Parameters.AddWithValue("@TcNo", textBox3.Text);
                    command.Parameters.AddWithValue("@P_Name", textBox4.Text);
                    command.Parameters.AddWithValue("@P_Surname", textBox5.Text);
                    command.Parameters.AddWithValue("@Address_", textBox6.Text);
                    command.Parameters.AddWithValue("@Birthdate", dateTimePicker1.Value.ToString("yyyy-MM-dd"));
                    command.Parameters.AddWithValue("@Sex", Cinsiyet);
                    command.Parameters.AddWithValue("@MobileNo", textBox7.Text);
                    command.Parameters.AddWithValue("@Email", textBox8.Text);
                    command.Parameters.AddWithValue("@RegisterDate", dateTimePicker2.Value.ToString("yyyy-MM-dd"));
                    command.ExecuteNonQuery();
                    dataTablo();
                    MessageBox.Show("Kayıt başarıyla eklendi");
                    ClearControls();
                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }

            bag.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Patient SET Address_=@adress, MobileNo=@mobileno, Email=@email WHERE PatientID=@patientId";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@adress", textBox6.Text);
                    command.Parameters.AddWithValue("@mobileno", textBox7.Text);
                    command.Parameters.AddWithValue("@email", textBox8.Text);
                    command.Parameters.AddWithValue("@patientId", int.Parse(textBox1.Text));

                    int rowAffected = command.ExecuteNonQuery();
                    dataTablo();
                    if (rowAffected > 0)
                    {
                        MessageBox.Show("Kayıt başarıyla güncellendi");
                        ClearControls();
                    }
                    else { MessageBox.Show("Güncelleme Başarısız. ID Bulunamadı!"); }

                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM Patient WHERE PatientID=@patientId";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@patientId", int.Parse(textBox1.Text));

                    int rowAffected = command.ExecuteNonQuery();
                    dataTablo();
                    if (rowAffected > 0)
                    {
                        MessageBox.Show("Kayıt başarıyla silindi");
                        ClearControls();
                    }
                    else { MessageBox.Show("Silme Başarısız. ID Bulunamadı!"); }
                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Patient WHERE TcNo = @tcno";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@tcno", textBox3.Text);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dT = new DataTable();
                    adapter.Fill(dT);
                    dataGridView1.DataSource = dT;
                    
                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            this.Hide();
            form5.Show();
        }
    }
}