﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace B210109063_SeymenCanAydogan
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }
        SqlConnection bag = new SqlConnection("server=HP-LAPTOP\\SQLEXPRESS; Initial Catalog=Hospital_Database; Integrated Security=SSPI");
        private void Form7_Load(object sender, EventArgs e)
        {
            int StaffID_ = 0;
            if (Form3.DoktorIDveri != 0) {StaffID_ = Form3.DoktorIDveri;}
            else { StaffID_= Form4.TipSekIDveri;}
            bag.Open();

            string query = "SELECT * FROM Staff WHERE StaffID = @StaffID_";

            SqlCommand command = new SqlCommand(query, bag);

            command.Parameters.AddWithValue("@StaffID_", StaffID_);

            SqlDataReader reader = command.ExecuteReader();

            if (reader.Read())
            {
                label6.Text = reader["StaffID"].ToString();
                label9.Text = reader["RecordNo"].ToString();
                label32.Text = reader["TcNo"].ToString();
                label10.Text = reader["S_Name"].ToString();
                label18.Text = reader["S_Surname"].ToString();
                label28.Text = reader["Address_"].ToString();
                label29.Text = reader["Birthdate"].ToString();
                label26.Text = reader["Sex"].ToString();
                label25.Text = reader["MobileNo"].ToString();
                label19.Text = reader["Email"].ToString();
                label16.Text = reader["Education"].ToString();
                label13.Text = reader["DipNo"].ToString();
                label23.Text = reader["DegreeID"].ToString();
                label12.Text = reader["ClinicID"].ToString();
                label11.Text = reader["HospID"].ToString();
            }
            else
            {
                MessageBox.Show("Kayıt Bulunamadı");
            }

            reader.Close();
            command.Dispose();
            bag.Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if (Form3.DoktorIDveri != 0) {
                Form6 form6 = new Form6();
                this.Hide();
                form6.Show();
            }
            else {
                Form5 form5 = new Form5();
                this.Hide();
                form5.Show();
            }
        }
    }
}
