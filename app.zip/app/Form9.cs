﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace B210109063_SeymenCanAydogan
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }
        SqlConnection bag = new SqlConnection("server=HP-LAPTOP\\SQLEXPRESS; Initial Catalog=Hospital_Database; Integrated Security=SSPI");

        void dataTablo()
        {
            string queryx = "SELECT * FROM Examination";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
        }

        private void ClearControls()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            richTextBox1.Text = "";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Examination(PatientID,ClinicID,DoctorID,Report_,ExaminationDate) VALUES(@patientId,@clinicId,@doctorId,@report,@exdate)";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@patientId", textBox2.Text);
                    command.Parameters.AddWithValue("@clinicId", textBox3.Text);
                    command.Parameters.AddWithValue("@doctorId", textBox4.Text);
                    command.Parameters.AddWithValue("@report", richTextBox1.Text);
                    command.Parameters.AddWithValue("@exdate", dateTimePicker2.Value.ToString("yyyy-MM-dd"));
                    command.ExecuteNonQuery();
                    dataTablo();
                    MessageBox.Show("Muayene Kayıt başarıyla eklendi");
                    ClearControls();
                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }

            bag.Close();
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            dataTablo();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Examination SET ExaminationDate=@exdate WHERE ExaminationID=@exId";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@exdate", dateTimePicker2.Value.ToString("yyyy-MM-dd"));
                    command.Parameters.AddWithValue("@exId", int.Parse(textBox1.Text));

                    int rowAffected = command.ExecuteNonQuery();
                    dataTablo();
                    if (rowAffected > 0)
                    {
                        MessageBox.Show("Muayene Kayıt başarıyla güncellendi");
                        ClearControls();
                    }
                    else { MessageBox.Show("Güncelleme Başarısız. ID Bulunamadı!"); }

                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM Examination WHERE ExaminationID=@exId";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@exId", int.Parse(textBox1.Text));

                    int rowAffected = command.ExecuteNonQuery();
                    dataTablo();
                    if (rowAffected > 0)
                    {
                        MessageBox.Show("Kayıt başarıyla silindi");
                        ClearControls();
                    }
                    else { MessageBox.Show("Silme Başarısız. ID Bulunamadı!"); }
                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Examination WHERE PatientID = @patientId";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@patientId", textBox2.Text);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dT = new DataTable();
                    adapter.Fill(dT);
                    dataGridView1.DataSource = dT;

                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            this.Hide();
            form5.Show();
        }
    }
}
