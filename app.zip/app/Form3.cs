﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace B210109063_SeymenCanAydogan
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        
        public static int DoktorIDveri = 0;
        SqlConnection bag = new SqlConnection("server=HP-LAPTOP\\SQLEXPRESS; Initial Catalog=Hospital_Database; Integrated Security=SSPI");
        private void Form3_Load(object sender, EventArgs e)
        {
            bag.Open();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int staffID = 0;
            bool isNumeric = int.TryParse(textBox1.Text, out staffID);
            string password = textBox2.Text;
            string query  = $"SELECT COUNT(*) FROM Admin_ A INNER JOIN Staff S ON S.StaffID = A.StaffID WHERE A.StaffID = '{staffID}' AND A.Password_ = '{password}' AND S.DegreeID <> 7";
            using (SqlCommand command = new SqlCommand(query, bag))
                {
                    int count = (int)command.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show("Giriş başarılı! Hoşgeldiniz.");
                        DoktorIDveri = Convert.ToInt32(textBox1.Text);
                        bag.Close();
                        Form6 form6 = new Form6();
                        this.Hide();
                        form6.Show();
                    }
                    else
                    {
                        MessageBox.Show("Hatalı Hekim ID veya Şifre!");
                    }
                }
            
            }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.Show();
        }
    }
    }

