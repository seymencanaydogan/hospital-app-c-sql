﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace B210109063_SeymenCanAydogan
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }
        SqlConnection bag = new SqlConnection("server=HP-LAPTOP\\SQLEXPRESS; Initial Catalog=Hospital_Database; Integrated Security=SSPI");

        void dataTablo()
        {
            string queryx = "SELECT * FROM AppointmentReq";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
        }
        private void Form10_Load(object sender, EventArgs e)
        {
            dataTablo();
            bag.Open();
            string query = "SELECT S_Name,S_Surname FROM Staff WHERE DegreeID <> 7";
            string query2 = "SELECT CommercialName FROM Hospital";
            string query3 = "SELECT ClinicName FROM Clinic";
            SqlCommand command = new SqlCommand(query, bag);
            SqlCommand command2 = new SqlCommand(query2, bag);
            SqlCommand command3 = new SqlCommand(query3, bag);

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                string name = reader["S_Name"].ToString();
                string surname = reader["S_Surname"].ToString();
                string fullname = name + " " + surname;
                listBox2.Items.Add(fullname);

            }
            reader.Close();
            command.Dispose();

            SqlDataReader reader2 = command2.ExecuteReader();
            while (reader2.Read())
            {
                string name = reader2["CommercialName"].ToString();
                listBox1.Items.Add(name);

            }
            reader2.Close();
            command2.Dispose();

            SqlDataReader reader3 = command3.ExecuteReader();

            while (reader3.Read())
            {
                string name = reader3["ClinicName"].ToString();
                listBox3.Items.Add(name);

            }
            reader3.Close();
            command3.Dispose();
            bag.Close();
        }

        private void ClearControls()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            richTextBox1.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string secildi = "NULL";
            if (radioButton1.Checked == true) { secildi = radioButton1.Text; }
            else if (radioButton2.Checked == true) { secildi = radioButton2.Text; }

            string query = "INSERT INTO AppointmentReq(PatientID,TcNo,AppointmentDate,HospitalName,ClinicName,DoctorName,Report,Status_) VALUES(@patId,@tcno,@apDate,@hospName,@clName,@docName,@rep,@st)";

            try
            {
                    bag.Open();
                    using (SqlCommand command = new SqlCommand(query, bag))
                    {
                        command.Parameters.AddWithValue("@patId", int.Parse(textBox2.Text));
                        command.Parameters.AddWithValue("@tcno", textBox3.Text);
                        command.Parameters.AddWithValue("@apDate", dateTimePicker2.Value.ToString("yyyy-MM-dd"));
                        command.Parameters.AddWithValue("@hospName", listBox1.SelectedItem.ToString());
                        command.Parameters.AddWithValue("@clName", listBox3.SelectedItem.ToString());
                        command.Parameters.AddWithValue("@docName", listBox2.SelectedItem.ToString());
                        command.Parameters.AddWithValue("@rep", richTextBox1.Text);
                        command.Parameters.AddWithValue("@st", secildi);
                        command.ExecuteNonQuery();
                        dataTablo();
                        MessageBox.Show("Randevu oluşturuldu!");
                        ClearControls();
                    }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }

            bag.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string secildi = "NULL";
            if (radioButton1.Checked == true) { secildi = radioButton1.Text; }
            else if (radioButton2.Checked == true) { secildi = radioButton2.Text; }
            string query = "UPDATE AppointmentReq SET Status_=@st WHERE AppointmentID=@apId";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@st", secildi);
                    command.Parameters.AddWithValue("@apId", int.Parse(textBox1.Text));

                    int rowAffected = command.ExecuteNonQuery();
                    dataTablo();
                    if (rowAffected > 0)
                    {
                        MessageBox.Show("Randevu durumu başarıyla güncellendi");
                        ClearControls();
                    }
                    else { MessageBox.Show("Güncelleme Başarısız. ID Bulunamadı!"); }

                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM AppointmentReq WHERE AppointmentID=@apId";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@apId", int.Parse(textBox1.Text));

                    int rowAffected = command.ExecuteNonQuery();
                    dataTablo();
                    if (rowAffected > 0)
                    {
                        MessageBox.Show("Randevu başarıyla silindi");
                        ClearControls();
                    }
                    else { MessageBox.Show("Silme Başarısız. ID Bulunamadı!"); }
                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM AppointmentReq WHERE PatientID = @patientId";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@patientId", textBox2.Text);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dT = new DataTable();
                    adapter.Fill(dT);
                    dataGridView1.DataSource = dT;

                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            this.Hide();
            form5.Show();
        }
    }
}
