﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace B210109063_SeymenCanAydogan
{
    public partial class Form15 : Form
    {
        public Form15()
        {
            InitializeComponent();
        }
        SqlConnection bag = new SqlConnection("server=HP-LAPTOP\\SQLEXPRESS; Initial Catalog=Hospital_Database; Integrated Security=SSPI");

        private void ClearControls()
        {
            textBox1.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
        }

        void dataTablo1()
        {
            string queryx = "SELECT * FROM Examination ORDER BY ExaminationDate DESC ";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
        }

        void dataTablo2()
        {
            string queryx = "SELECT * FROM Analysis ";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView2.DataSource = dataTable;
            }
        }


        void dataTablo3()
        {
            string queryx = "SELECT * FROM ExaminationAn ";
            using (SqlCommand commandx = new SqlCommand(queryx, bag))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(commandx);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridView3.DataSource = dataTable;
            }
        }

        private void Form15_Load(object sender, EventArgs e)
        {
            dataTablo1();
            dataTablo2();
            dataTablo3();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Examination WHERE ExaminationID = @exId";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@exId", int.Parse(textBox1.Text));

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dT = new DataTable();
                    adapter.Fill(dT);
                    dataGridView1.DataSource = dT;

                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataTablo1();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Analysis WHERE AnalysisTitle = @anTit";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@anTit", textBox3.Text);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dT = new DataTable();
                    adapter.Fill(dT);
                    dataGridView2.DataSource = dT;

                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            dataTablo2();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO ExaminationAn(ExaminationID,AnalysisID) VALUES(@exId,@anId)";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@exId", int.Parse(textBox5.Text));
                    command.Parameters.AddWithValue("@anId", int.Parse(textBox4.Text));
                    command.ExecuteNonQuery();
                    dataTablo3();
                    MessageBox.Show("Muaneye tahlil istemi başarıyla eklendi");
                    ClearControls();
                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM ExaminationAn WHERE ExaminationID=@exId AND AnalysisID=@anId";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@exId", int.Parse(textBox5.Text));
                    command.Parameters.AddWithValue("@anId", int.Parse(textBox4.Text));

                    int rowAffected = command.ExecuteNonQuery();
                    dataTablo3();
                    if (rowAffected > 0)
                    {
                        MessageBox.Show("Muaneden tahlil istemi başarıyla silindi");
                        ClearControls();
                    }
                    else { MessageBox.Show("Silme Başarısız. ID Bulunamadı!"); }
                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM ExaminationAn WHERE AnalysisID = @anId";
            try
            {
                bag.Open();
                using (SqlCommand command = new SqlCommand(query, bag))
                {
                    command.Parameters.AddWithValue("@anId", int.Parse(textBox4.Text));

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dT = new DataTable();
                    adapter.Fill(dT);
                    dataGridView3.DataSource = dT;

                }
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }
            bag.Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            this.Hide();
            form6.Show();
        }
    }
}
