﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace B210109063_SeymenCanAydogan
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        SqlConnection bag = new SqlConnection("server=HP-LAPTOP\\SQLEXPRESS; Initial Catalog=Hospital_Database; Integrated Security=SSPI");
        Form1 form1 = new Form1();
        private void ClearControls()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            richTextBox1.Text = "";
            checkBox1.Checked = false;
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            bag.Open();
            string query = "SELECT S_Name,S_Surname FROM Staff WHERE DegreeID <> 7";
            string query2 = "SELECT CommercialName FROM Hospital";
            string query3 = "SELECT ClinicName FROM Clinic";
            SqlCommand command = new SqlCommand(query, bag);
            SqlCommand command2 = new SqlCommand(query2, bag);
            SqlCommand command3 = new SqlCommand(query3, bag);

            SqlDataReader reader = command.ExecuteReader();  

            while (reader.Read())
            {
                    string name = reader["S_Name"].ToString();
                    string surname = reader["S_Surname"].ToString();
                    string fullname = name + " " + surname;
                    listBox2.Items.Add(fullname);
                
            }
            reader.Close();
            command.Dispose();

            SqlDataReader reader2 = command2.ExecuteReader();
            while (reader2.Read())
            {
                string name = reader2["CommercialName"].ToString();
                listBox1.Items.Add(name);

            }
            reader2.Close();
            command2.Dispose();

            SqlDataReader reader3 = command3.ExecuteReader();
            
            while (reader3.Read())
            {
                string name = reader3["ClinicName"].ToString();
                listBox3.Items.Add(name);

            }
            reader3.Close();
            command3.Dispose();
            bag.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO AppointmentReq(PatientID,TcNo,AppointmentDate,HospitalName,ClinicName,DoctorName,Report) VALUES(@patId,@tcno,@apDate,@hospName,@clName,@docName,@rep)";

            try
            {
                bag.Open();
                if (checkBox1.Checked == true)
                {
                    using (SqlCommand command = new SqlCommand(query, bag))
                    {
                        command.Parameters.AddWithValue("@patId", int.Parse(textBox1.Text));
                        command.Parameters.AddWithValue("@tcno", textBox2.Text);
                        command.Parameters.AddWithValue("@apDate", dateTimePicker1.Value.ToString("yyyy-MM-dd"));
                        command.Parameters.AddWithValue("@hospName", listBox1.SelectedItem.ToString());
                        command.Parameters.AddWithValue("@clName", listBox3.SelectedItem.ToString());
                        command.Parameters.AddWithValue("@docName", listBox2.SelectedItem.ToString());
                        command.Parameters.AddWithValue("@rep", richTextBox1.Text);

                        command.ExecuteNonQuery();
                        MessageBox.Show("Talebiniz başarıyla gönderildi. Onaylandığında, cep telefonunuza SMS gelecektir.");
                        ClearControls();
                    }
                }
                else
                {
                    MessageBox.Show("KVKK şartlarını kabul ediniz!");
                }
               
            }
            catch (Exception hata)
            {
                MessageBox.Show(hata.Message);
            }

            bag.Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.Show();

        }
    }
    }

